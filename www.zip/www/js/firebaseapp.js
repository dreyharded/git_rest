var config = {
    apiKey: "AIzaSyB9MGQZJrqmXcTUhbj2O7X7hasFmoyDsHs",
    authDomain: "bikcraft-78d52.firebaseapp.com",
    databaseURL: "https://bikcraft-78d52.firebaseio.com",
    projectId: "bikcraft-78d52",
    storageBucket: "bikcraft-78d52.appspot.com",
    messagingSenderId: "1020818667426"
  };
  firebase.initializeApp(config);